'use strict';
// Declare app level module which depends on filters, and services
var template = angular.module('myApp',['myApp.services', 'myApp.controllers']);

template.config(['$routeProvider',
		function ($routeProvider) {
			for (var template in appData.views)
			{
				$routeProvider.when(
					appData.views[template].url, {
						template: appData.views[template].template,
						controller: appData.views[template].controller
					}
				);
			}
		}
	]
);
