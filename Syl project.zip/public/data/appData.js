var appData = {
	"views": {
		"phoneData": {
			"controller": "phoneController",
			"template":"",
			"url": "/",
			"data": {
				"title": "Our Suggestion is:",
				"Phones": [
					{
 "Model": "Motorola Droid Turbo 2",
"Description":"5.4-inch display,Amoled,540 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 430 GPU,3 GB RAM,16/32GB Internal with Expandable Storage upto 200 GB,21 MP Rear Camera with Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3760 mAh,Android 5.1.1",
"pros": "Shatterproof Screen,Stock Android,MicroSD expansion,TurboPower charging,Timely updates likely,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Non Removable battery,Screen gets a bit warm at times" ,
"rating":"7",
"Positive": "2",
  "Negative": "2",
  "Overall": "2"                        
					}, 
					{
					"Model": "HTC One M9",
"Description":"5.0-inch display,Super LCD3,441 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 430 GPU,3 GB RAM,32GB Internal with Expandable Storage upto 200 GB,20 MP Rear Camera with Flash,4 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2840 mAh,Android 5.0",
"pros": "Full metal design,Boomsound,MicroSD expansion,TurboPower charging,,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Non Removable battery,Camera lacks OIS,Not water resistant,No 4k Video Recording",
"rating":"5",
"Positive": "2",
"Negative": "2",
"Overall": "2"                        
    }, 
{
"Model": "Apple Iphone 6s Plus",
"Description":"5.50-inch display,IPS LCD,401 PPI,1.3GHz Dual-Core Apple A9 Chip ,2 GB RAM,16GB/32GB/64GB/128GB Internal without Expandable Storage ,12 MP Rear Camera with Flash,5 MP Front Camera with flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,With NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2750 mAh,iOS 9",
"pros": "Full metal design,Great design,Fantastic performance,3D Touch enables new UI paradigms,Clean software experience,Much improved camera,Retina Flash on the front is great",
"cons":"Touch ID is too fast,16GB storage in base variant is very less,Expensive,More big-screen software features would be welcome",
 "rating":"6",  
 "Positive": "2",
  "Negative": "3",
  "Overall": "1"    
}, {
"Model": "Google/Huawei Nexus 6p",
"Description":"5.7-inch display,Amoled,518 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3 GB RAM,32GB/64GB Internal without Expandable Storage ,12.3 MP Rear Camera with Flash,8 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3450 mAh,Android 6.0",
"pros": "Great design and build,Fantastic display,Excellent camera,Clean software experience,Blazing performance and software,Very competitive price,Supports LTE,Reliable performer",
"cons":"Non Removable battery,No wireless charging,Not water resistant,No microSD slot",
"rating":"4", 
"Positive": "4",
  "Negative": "1",
  "Overall": "5"    
} ,{
"Model": "OnePlus Two",
"Description":"5.50-inch display,IPS LCD,401 PPI,1.8GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3/4 GB RAM,32GB/64GB Internal without Expandable Storage,13 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3300 mAh,Android 5.0 with OxygenOS 2.0",
"pros": "Blazing fast performance,Good battery life,Decent camera,Dual SIM flagship,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Fingerprint scanner doesn't always work,Other software bugs,Not water resistant,No NFC",
"rating":"8",
"Positive": "4",
  "Negative": "3",
  "Overall": "5"    
}, 
                {
"Model": "Moto X Style",
"Description":"5.7 inch display ,Amoled,515 PPI,1.8GHz Hexa-Core Qualcomm Snapdragon 808 with Adreno 418 GPU,3 GB RAM,16/32/64GB Internal with Expandable Storage upto 128 GB,21 MP Rear Camera with Dual Led Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3000 mAh,Android 5.1.1",
"pros": "Moto Maker customisation, Beautiful build quality,MicroSD expansion, TurboPower charging,Large vibrant display,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Loud front-facing speakers",
"cons":"Average battery life,slight performance hiccups",
"rating":"7",
"Positive": "4",
"Negative": "2",
"Overall": "3"                    
},
 {
"Model": "Moto G3",
"Description":"5.0-inch display ,IPS LCD,294 PPI,1.4GHz Quad-Core Qualcomm Snapdragon 410 with Adreno 418 GPU,1 GB RAM,8GB Internal with Expandable Storage upto 32 GB,13 MP Rear Camera with Led Flash,5 MP Front Camera without Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2470 mAh,Android 5.1.1",
"pros": "IPX7 water resistance, Stock Android,MicroSD expansion, TurboPower charging,Large vibrant display,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Average battery life,Screen gets a bit warm at times",
"rating":"5",
"Positive": "4",
"Negative": "1",
"Overall": "4"     
},                    
 {
"Model": "Moto E",
"Description":"4.50-inch display,IPS LCD,245 PPI,1.2GHz Quad-Core Qualcomm Snapdragon 410 with Adreno 418 GPU,1 GB RAM,8GB Internal with Expandable Storage upto 32 GB,5 MP Rear Camera without Flash,0.3 MP Front Camera without Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2390 mAh,Android 5.0.2",
"pros": "Great,functional design,Stock Android,MicroSD expansion,Intuitive software tweaks,Inexpensive,Clean software experience,Very competitive price,Supports LTE",
"cons":"Bad camera performance,Low-resolution screen,Call drops",
"rating":"3",
"Positive": "4",
  "Negative": "1",
  "Overall": "5"
},
                 {
"Model": "Sony Xperia Z5",
"Description":"5.2-inch display,IPS LCD,424 PPI,2.4GHz Quad-Core Qualcomm Snapdragon 808 with Adreno 418 GPU,3 GB RAM,32GB Internal with Expandable Storage upto 200 GB,23 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2900 mAh,Android 5.1.1",
"pros": "Looks good,Good battery life,MicroSD expansion,Strong all-round performance,Clean software experience,Weatherproof",
"cons":"Heats up quickly,Pre-installed bloatware,Not water resistant,Slow camera, No Burst mode in camera",
"rating":"6",
"Positive": "5",
"Negative": "2",
"Overall": "4"                     
},
{
"Model": "OnePlus One",
"Description":"5.50-inch display,IPS LCD,401 PPI,2.5GHz Quad-Core Qualcomm Snapdragon 801 with Adreno 418 GPU,3GB RAM,32GB/64GB Internal without Expandable Storage,13 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3100 mAh,CyanogenMod 11S",
"pros": "Blazing fast performance,Good battery life,Decent camera,Dual SIM flagship,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer,Flexible CyanogenMod OS",
"cons":"Average camera,Disappointing battery life,Restricted Availablity",
"rating":"9",
"Positive": "3",
"Negative": "2",
"Overall": "3"   
},                    
{
"Model": "OnePlus X",
"Description":"5.00-inch display,IPS LCD,441 PPI,2.3GHz Quad-Core Qualcomm Snapdragon 801 with Adreno 418 GPU,3GB RAM,32GB/64GB Expandable Storage upto 128gb,13 MP Rear Camera with Flash,8 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2525 mAh,OxygenOS 2.1",
"pros": "Looks good,Great display,Decent performance,Good software",
"cons":"Poor camera performance,Heat dissipation issues affect battery life,Questionable build quality",
"rating":"9",
"Positive": "4",
"Negative": "3",
"Overall": "4"        
},
{
"Model": "Apple Iphone 5c",
"Description":"4.00-inch display,IPS LCD,326  PPI,1.3GHz Dual-Core Apple A6 Chip ,1 GB RAM,16GB Internal without Expandable Storage ,8 MP Rear Camera with Flash,1.2 MP Front Camera with flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,With NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2525 mAh,iOS 7",
"pros":"Solid in all departments,Great display,Decent performance,iOS ecosystem remains unrivaled",
"cons":"Not as future-proof as the 5s,16GB storage in base variant is very less,Expensive,Questionable value for money,Questionable build quality",
"rating":"4",
"Positive": "1",
"Negative": "4",
"Overall": "-3"    
}, 
{
"Model": "Apple Iphone 6s",
"Description":"4.70-inch display,IPS LCD,326  PPI,1.3GHz Dual-Core Apple A9 Chip ,2 GB RAM,16GB/32GB/64GB/128GB Internal without Expandable Storage ,12 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,With NFC Support,4G HSPA Supported in all bands,Battery Capacity of 1715 mAh,iOS 9",
"pros":"Great designs,Great display,Fantastic performance,3D Touch enables new UI paradigms",
"cons":"Touch ID is too fast,16GB storage in base variant is very less,Expensive,Questionable value for money,Battery life could be better",
"rating":"5", 
"Positive": "1",
"Negative": "4",
"Overall": "-3"    
},
  {
"Model": "Sony Xperia Z5 Compact",
"Description":"4.60 inch display,Amoled,424 PPI,2.4GHz Quad-Core Qualcomm Snapdragon 808 with Adreno 418 GPU,2 GB RAM,32GB Internal with Expandable Storage upto 200 GB,23 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2700 mAh,Android 5.1.1",
"pros": "Looks good,Good battery life,MicroSD expansion,Strong all-round performance,Clean software experience,Weatherproof",
"cons":"Heats up quickly,Pre-installed bloatware,Not water resistant,Slow camera, No Burst mode in camera",
"rating":"6",
"Positive": "5",
  "Negative": "2",
  "Overall": "4"      
},                    
 {
"Model": "Google/LG Nexus 5X",
"Description":"5.0-inch display,Amoled,518 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3 GB RAM,32GB/64GB Internal without Expandable Storage ,12.3 MP Rear Camera with Flash,8 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2700 mAh,Android 6.0",
"pros": "Great design and build,Fantastic display,Excellent camera,Clean software experience,Blazing performance and software,Very competitive price,Supports LTE,Reliable performer",
"cons":"Non Removable battery,No wireless charging,Not water resistant,No microSD slot,Ditches wireless charging",
"rating":"8",
 "Positive": "3",
  "Negative": "2",
  "Overall": "2"     
     
},
                    
  {
					"Model": "HTC One A9",
"Description":"5.0-inch display,Super LCD3,441 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 617 with Adreno 405 GPU,3 GB RAM,32GB Internal with Expandable Storage upto 200 GB,20 MP Rear Camera with Flash,4 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2150 mAh,Android 6.0",
"pros": "Lots of RAM to handle all heavy apps & games,Smooth gaming experience,Primary Camera shoots Awesome high quality pics,TurboPower charging,,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Good Octa-core processor for Flawless performance",
"cons":"Non Removable battery,Camera lacks OIS,Not water resistant,No 4k Video Recording",
"rating":"2",
"Positive Sentiment": "1",
  "Negative": "3",
  "Overall": "1"      
    },
                    
{
					"Model": "BlackBerry Priv",
"Description":"5.4 inch display,AMOLED,540 PPI,1.8GHz Octa-Core Qualcomm Snapdragon 808 with Adreno 418 GPU,3 GB RAM,32GB Internal with Expandable Storage upto 200 GB,18 MP Rear Camera with Flash,2 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3410 mAh,Android 5.1.1",
"pros": "Active noise cancellation with dedicated mic,Fast battery charging: 60% in 30 min,Clean software experience,Optional Wireless Charging,Supports LTE",
"cons":"Bland design,Non-removable battery,Keyboard less tactile",
"rating":"4",
"Positive": "1",
"Negative": "4",
"Overall": "1"    
    },
    {
					"Model": "Lenovo K4 Note",
"Description":"5.5 inch display,AMOLED,403 PPI,1.3GHz Octa-Core MediaTek MT6753 with Adreno 418 GPU,3 GB RAM,16GB Internal with Expandable Storage upto 128 GB,13 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3300 mAh,Android 5.1.1",
"pros": "Good camera,Fingerprint sensor,Clean software experience,Good overall performance,Supports LTE",
"cons":"Screen resolution is bad,Uses bloatware",
"rating":"6",
"Positive": "4",
"Negative": "3",
"Overall": "4"        
    },
                    
  {
"Model": "LG G4",
"Description":"5.5-inch display ,IPS Quantum display,515 PPI,1.8GHz Hexa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3 GB RAM,16/32/64GB Internal with Expandable Storage upto 128 GB,16 MP Rear Camera with Dual Led Flash,8 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3000 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Has a microSD card slot, Bright, vibrant screen,Secondary 2.1 located above primary 5.7 QHD that can display settings, apps and any other information that seem to be relevant in always on Mode",
"cons":"Bland design, aside from that nice leather option,Trails its rivals in gaming performances,LG didn't include its Quick Charge technology",
"rating":"5",
"Positive": "3",
"Negative": "2",
"Overall": "3"      
},
 {
"Model": "LG V10",
"Description":"5.7-inch display ,IPS Quantum display,515 PPI,1.8GHz Hexa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,4 GB RAM,32GB/64GB/128GB Internal with Expandable Storage upto 2TB,16 MP Rear Camera with Dual Led Flash,8 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3000 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Has a microSD card slot, Bright, vibrant screen,Secondary 2.1 located above primary 5.7 QHD that can display settings, apps and any other information that seem to be relevant in always on Mode,4K Video recording,Dual Display",
"cons":"Bland design, aside from that nice leather option,Trails its rivals in gaming performances,LG didn't include its Quick Charge technology",
"rating":"9", 
"Positive": "4",
"Negative": "1",
"Overall": "4"     
},
{
"Model": "Samsung galaxy s6",
"Description":"5.10-inch display ,Amoled display,577 PPI,1.5GHz Octa-Core Samsung Exynos 7420 with Adreno 418 GPU,3 GB RAM,32GB/64GB/128GB Internal without Expandable Storage,16 MP Rear Camera with Dual Led Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2550 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Fantastic performance,Unmatched original style,Sturdy and attractive metal body",
"cons":"No microSD slot,Pre-installed bloatware,Difficult to grip securely,Awkward camera bulge",
"rating":"4" ,
"Positive": "5",
"Negative": "2",
"Overall": "5"    
},
{
"Model": "Samsung Note 5",
"Description":"5.7 inch display ,Amoled display,518 PPI,1.5GHz Octa-Core Samsung Exynos 7420 with Adreno 418 GPU,4 GB RAM,32GB/64GB/128GB Internal without Expandable Storage,16 MP Rear Camera with Dual Led Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2550 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Fantastic performance,Unmatched original style,Sturdy and attractive metal body,Good battery life",
"cons":"No microSD slot,Pre-installed bloatware,Difficult to grip securely,AS Pen mechanism prone to damage,No IR blaster",
"rating":"3", 
"Positive": "5",
"Negative": "2",
"Overall": "5"     
},
{
"Model": "Samsung galaxy s6 Edge",
"Description":"5.10-inch display ,Amoled display,577 PPI,1.5GHz Octa-Core Samsung Exynos 7420 with Adreno 418 GPU,3 GB RAM,32GB/64GB/128GB Internal without Expandable Storage,16 MP Rear Camera with Dual Led Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2600 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Fantastic performance,Unmatched original style,Sturdy and attractive metal body",
"cons":"No microSD slot,Pre-installed bloatware,Difficult to grip securely,Awkward camera bulge",
"rating":"7",
 "Positive": "5",
"Negative": "2",
"Overall": "5"    
} 
]
			}
		},
    "flagshipData": {
			"controller": "FlagshipController",
			"template": "",
			"url": "/flagship",
			"data": {
                
    "flagshipPhones": [
    {
"Model": "Samsung Note 5",
"Description":"5.7 inch display ,Amoled display,518 PPI,1.5GHz Octa-Core Samsung Exynos 7420 with Adreno 418 GPU,4 GB RAM,32GB/64GB/128GB Internal without Expandable Storage,16 MP Rear Camera with Dual Led Flash,5 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2550 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Fantastic performance,Unmatched original style,Sturdy and attractive metal body,Good battery life",
"cons":"No microSD slot,Pre-installed bloatware,Difficult to grip securely,AS Pen mechanism prone to damage,No IR blaster",
"rating":"3", 
"Positive": "5",
"Negative": "2",
"Overall": "5"     
},
{
"Model": "OnePlus Two",
"Description":"5.50-inch display,IPS LCD,401 PPI,1.8GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3/4 GB RAM,32GB/64GB Internal without Expandable Storage,13 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3300 mAh,Android 5.0 with OxygenOS 2.0",
"pros": "Blazing fast performance,Good battery life,Decent camera,Dual SIM flagship,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Fingerprint scanner doesn't always work,Other software bugs,Not water resistant,No NFC",
"rating":"8",
"Positive": "4",
  "Negative": "3",
  "Overall": "5"    
},  
{
"Model": "Google/Huawei Nexus 6p",
"Description":"5.7-inch display,Amoled,518 PPI,2.0GHz Octa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,3 GB RAM,32GB/64GB Internal without Expandable Storage ,12.3 MP Rear Camera with Flash,8 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3450 mAh,Android 6.0",
"pros": "Great design and build,Fantastic display,Excellent camera,Clean software experience,Blazing performance and software,Very competitive price,Supports LTE,Reliable performer",
"cons":"Non Removable battery,No wireless charging,Not water resistant,No microSD slot",
"rating":"4", 
"Positive": "4",
  "Negative": "1",
  "Overall": "5"    
},
{
"Model": "LG V10",
"Description":"5.7-inch display ,IPS Quantum display,515 PPI,1.8GHz Hexa-Core Qualcomm Snapdragon 810 with Adreno 418 GPU,4 GB RAM,32GB/64GB/128GB Internal with Expandable Storage upto 2TB,16 MP Rear Camera with Dual Led Flash,8 MP Front Camera with Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3000 mAh,Android 5.1.1",
"pros": "Mostly great cameras, Long battery life,Has a microSD card slot, Bright, vibrant screen,Secondary 2.1 located above primary 5.7 QHD that can display settings, apps and any other information that seem to be relevant in always on Mode,4K Video recording,Dual Display",
"cons":"Bland design, aside from that nice leather option,Trails its rivals in gaming performances,LG didn't include its Quick Charge technology",
"rating":"9", 
"Positive": "4",
"Negative": "1",
"Overall": "4"     
}        
]  
				
			}
		},
    "midData": {
			"controller": "MidtierController",
			"template": "",
			"url": "/midtier",
			"data": {
                
    "midtierPhones": [
    {
"Model": "Moto G3",
"Description":"5.0-inch display ,IPS LCD,294 PPI,1.4GHz Quad-Core Qualcomm Snapdragon 410 with Adreno 418 GPU,1 GB RAM,8GB Internal with Expandable Storage upto 32 GB,13 MP Rear Camera with Led Flash,5 MP Front Camera without Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2470 mAh,Android 5.1.1",
"pros": "IPX7 water resistance, Stock Android,MicroSD expansion, TurboPower charging,Large vibrant display,Clean software experience,Much improved camera,Very competitive price,Supports LTE,Reliable performer",
"cons":"Average battery life,Screen gets a bit warm at times",
"rating":"5",
"Positive": "4",
"Negative": "1",
"Overall": "4"     
},
{
"Model": "Sony Xperia Z5 Compact",
"Description":"4.60 inch display,Amoled,424 PPI,2.4GHz Quad-Core Qualcomm Snapdragon 808 with Adreno 418 GPU,2 GB RAM,32GB Internal with Expandable Storage upto 200 GB,23 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2700 mAh,Android 5.1.1",
"pros": "Looks good,Good battery life,MicroSD expansion,Strong all-round performance,Clean software experience,Weatherproof",
"cons":"Heats up quickly,Pre-installed bloatware,Not water resistant,Slow camera, No Burst mode in camera",
"rating":"6",
"Positive": "5",
  "Negative": "2",
  "Overall": "4"      
},  
{
"Model": "OnePlus X",
"Description":"5.00-inch display,IPS LCD,441 PPI,2.3GHz Quad-Core Qualcomm Snapdragon 801 with Adreno 418 GPU,3GB RAM,32GB/64GB Expandable Storage upto 128gb,13 MP Rear Camera with Flash,8 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2525 mAh,OxygenOS 2.1",
"pros": "Looks good,Great display,Decent performance,Good software",
"cons":"Poor camera performance,Heat dissipation issues affect battery life,Questionable build quality",
"rating":"9",
"Positive": "4",
"Negative": "3",
"Overall": "4"        
},
{
					"Model": "Lenovo K4 Note",
"Description":"5.5 inch display,AMOLED,403 PPI,1.3GHz Octa-Core MediaTek MT6753 with Adreno 418 GPU,3 GB RAM,16GB Internal with Expandable Storage upto 128 GB,13 MP Rear Camera with Flash,5 MP Front Camera without flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,No NFC Support,4G HSPA Supported in all bands,Battery Capacity of 3300 mAh,Android 5.1.1",
"pros": "Good camera,Fingerprint sensor,Clean software experience,Good overall performance,Supports LTE",
"cons":"Screen resolution is bad,Uses bloatware",
"rating":"6",
"Positive": "4",
"Negative": "3",
"Overall": "4"        
    }        
]  
				
			}
		},  
"budgetData": {
			"controller": "budgetController",
			"template": "/budget.html",
			"url": "/budget",
			"data": {
                
    "budgetPhones": [
    {
"Model": "Moto E",
"Description":"4.50-inch display,IPS LCD,245 PPI,1.2GHz Quad-Core Qualcomm Snapdragon 410 with Adreno 418 GPU,1 GB RAM,8GB Internal with Expandable Storage upto 32 GB,5 MP Rear Camera without Flash,0.3 MP Front Camera without Flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support, NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2390 mAh,Android 5.0.2",
"pros": "Great,functional design,Stock Android,MicroSD expansion,Intuitive software tweaks,Inexpensive,Clean software experience,Very competitive price,Supports LTE",
"cons":"Bad camera performance,Low-resolution screen,Call drops",
"rating":"3",
"Positive": "4",
  "Negative": "1",
  "Overall": "5"
},
{
"Model": "Apple Iphone 5c",
"Description":"4.00-inch display,IPS LCD,326  PPI,1.3GHz Dual-Core Apple A6 Chip ,1 GB RAM,16GB Internal without Expandable Storage ,8 MP Rear Camera with Flash,1.2 MP Front Camera with flash,802.11 b/g/n Wi-fi support,4.1 Bluetooth support,With NFC Support,4G HSPA Supported in all bands,Battery Capacity of 2525 mAh,iOS 7",
"pros":"Solid in all departments,Great display,Decent performance,iOS ecosystem remains unrivaled",
"cons":"Not as future-proof as the 5s,16GB storage in base variant is very less,Expensive,Questionable value for money,Questionable build quality",
"rating":"4",
"Positive": "1",
"Negative": "4",
"Overall": "2"    
}
]  
				
			}
		},        
        
        
        
	}
};
